package com.bank.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.bank.entity.Transactions;
import com.bank.service.IBankService;

//*********************************Controller**************************************//
@Controller
public class BankController {

@Autowired
private IBankService bankService;

@RequestMapping("/index.html")
public String dummy(Model model){
	model.addAttribute("transactionList",bankService.loadAll());
	model.addAttribute("retrieve",new Transactions());
	return "retrievetranscations";
}
@RequestMapping("/Retrieve")
public String dummys(Model model){
	model.addAttribute("transactionList",bankService.loadAll());
	model.addAttribute("retrieve",new Transactions());
	return "Retrieve";
}
	


}
