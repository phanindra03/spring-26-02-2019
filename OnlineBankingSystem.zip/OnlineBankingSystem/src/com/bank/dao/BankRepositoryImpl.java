package com.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.bank.entity.Transactions;


@Repository
public class BankRepositoryImpl implements IBankRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Transactions> loadAll() {
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e",Transactions.class);
		return query.getResultList();
	}

}
