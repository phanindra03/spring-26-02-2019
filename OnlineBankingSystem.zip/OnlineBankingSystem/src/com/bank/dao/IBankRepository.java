package com.bank.dao;

import java.util.List;
import com.bank.entity.Transactions;

public interface IBankRepository {
	
	List<Transactions> loadAll();

}
