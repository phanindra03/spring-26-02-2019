package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dao.IBankRepository;
import com.bank.entity.Transactions;


@Service
@Transactional
public class BankService implements IBankService{

	@Autowired
	private IBankRepository bankRepository;
	
	@Override
	public List<Transactions> loadAll() 
	{
		return bankRepository.loadAll();
	}

}
