package com.bank.service;

import java.util.List;

public interface IBankService<Transcations> {

 List<Transcations> loadAll();

}
